package com.example.analisador_texto

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
